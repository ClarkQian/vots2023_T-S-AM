import os

seq_path='/HDDs/hdd3/wff/documents/vots_test/sequences'
seq_list=os.listdir(seq_path)
seq_list=[i for i in seq_list if i!='list.txt']
seq_list=sorted(seq_list)
seq_dict={}
for index,seq in enumerate(seq_list):
    seq_dict[seq]=index+1


result_seq='/HDDs/hdd3/wff/documents/vots_test/results'
result_seq_list=os.listdir(result_seq)
result_seq_list=sorted(result_seq_list)
have=set()
for seq in result_seq_list:
    dir_list=os.listdir(seq_path+'/'+seq)
    first_frame_label=[i for i in dir_list if i.startswith('groundtruth')]
    f=open(seq_path+'/'+seq+'/'+first_frame_label[0],'r')
    line=f.readline()
    split_line=line.split(',')
    # if split_line[1]!='0':
    #     have.add(seq_dict[seq])
    seq_dir=os.listdir(result_seq+'/'+seq)
    seq_dir=[name for name in seq_dir if name.endswith('.mp4')]
    if len(seq_dir)!=0:
        have.add(seq_dict[seq])
print(have)
all=set([i for i in range(1,145)])
not_have=all-have
print(not_have)
for index in not_have:
    print(seq_list[index-1])