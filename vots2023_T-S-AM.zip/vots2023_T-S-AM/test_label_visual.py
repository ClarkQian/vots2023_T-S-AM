import torch
from torchvision.io import read_image
from torchvision.utils import draw_segmentation_masks
from torchvision import utils as vutils
from vot.region.io import parse_region,mask_to_rle

img_path='/HDDs/hdd3/wff/documents/vot_challenge_test/sequences/giraffe-15/color/00000001.jpg'
label_path='/HDDs/hdd3/wff/documents/vot_challenge_test/sequences/giraffe-15/groundtruth_3.txt'
save_path='/HDDs/hdd3/wff/documents/vot_challenge_test/sequences/giraffe-15/test_mask_3.png'


def read_label(label_path,width,height,frame_id):
    f=open(label_path,'r')
    lines=f.readlines()
    # mask=torch.zeros(height,width)
    line=lines[frame_id-1]
    mask=parse_region(line)
    string=mask_to_rle(mask.mask)
    return torch.from_numpy(mask.mask)
    # if line[0]=='m0':
    #     line=line[4:]
    #     index=0
    #     while True:
    #         if index+1 < len(line):
    #             x=int(line[index])
    #             y=int(line[index+1])
    #             mask[y][x]=1
    #             index+=2
    #         else:
    #             break
    # return mask

def draw_mask(img_path,mask,save_path):
    img=read_image(img_path)
    # We get the unique colors, as these would be the object ids.
    obj_ids = torch.unique(mask)
    # first id is the background, so remove it.
    obj_ids = obj_ids[1:]
    # split the color-encoded mask into a set of boolean masks.
    # Note that this snippet would work as well if the masks were float values instead of ints.
    masks = mask == obj_ids[:, None, None]
    drawn_masks = []
    for mask in masks:
        drawn_masks.append(draw_segmentation_masks(img, mask, alpha=0.8, colors="blue"))
    vutils.save_image(drawn_masks[0]/255.0, save_path)


mask=read_label(label_path,1280,720,1)
draw_mask(img_path,mask,save_path)