import os
import cv2
from SegTracker import SegTracker
from model_args import aot_args, sam_args, segtracker_args
from PIL import Image
from aot_tracker import _palette
import numpy as np
import torch
import imageio
import matplotlib.pyplot as plt
from scipy.ndimage import binary_dilation
import gc
from vot.region.io import parse_region,mask_to_rle
from scipy.optimize import linear_sum_assignment as sklearn_linear_assignment

def save_prediction(pred_mask, output_dir, file_name):
    save_mask = Image.fromarray(pred_mask.astype(np.uint8))
    save_mask = save_mask.convert(mode='P')
    save_mask.putpalette(_palette)
    save_mask.save(os.path.join(output_dir, file_name))


def colorize_mask(pred_mask):
    save_mask = Image.fromarray(pred_mask.astype(np.uint8))
    save_mask = save_mask.convert(mode='P')
    save_mask.putpalette(_palette)
    save_mask = save_mask.convert(mode='RGB')
    return np.array(save_mask)


def draw_mask(img, mask, alpha=0.5, id_countour=False):
    img_mask = np.zeros_like(img)
    img_mask = img
    if id_countour:
        # very slow ~ 1s per image
        obj_ids = np.unique(mask)
        obj_ids = obj_ids[obj_ids != 0]

        for id in obj_ids:
            # Overlay color on  binary mask
            if id <= 255:
                color = _palette[id * 3:id * 3 + 3]
            else:
                color = [0, 0, 0]
            foreground = img * (1 - alpha) + np.ones_like(img) * alpha * np.array(color)
            binary_mask = (mask == id)

            # Compose image
            img_mask[binary_mask] = foreground[binary_mask]

            countours = binary_dilation(binary_mask, iterations=1) ^ binary_mask
            img_mask[countours, :] = 0
    else:
        binary_mask = (mask != 0)
        countours = binary_dilation(binary_mask, iterations=1) ^ binary_mask
        foreground = img * (1 - alpha) + colorize_mask(mask) * alpha
        img_mask[binary_mask] = foreground[binary_mask]
        img_mask[countours, :] = 0

    return img_mask.astype(img.dtype)


# TODO 新增根据跟踪目标mask判断跟踪目标id函数
def find_tracking_ids(pred_mask,obj_ids,obj_masks,matching_threshold=0.3):
    pred_objs_mask=[]
    for id in obj_ids:
        pred_objs_mask.append(pred_mask==id)
    pred_objs_mask=np.array(pred_objs_mask)
    gt_objs_masks=obj_masks.reshape(obj_masks.shape[0],1,obj_masks.shape[1],obj_masks.shape[2])
    pred_objs_mask=pred_objs_mask.reshape(1,*pred_objs_mask.shape)
    inter=np.sum(gt_objs_masks*pred_objs_mask,axis=-1)
    inter=np.sum(inter,axis=-1)
    union=(gt_objs_masks+pred_objs_mask)>0
    union=np.sum(union,axis=-1)
    union = np.sum(union, axis=-1)
    iou=inter/union
    cost=1-iou
    match_pairs=sklearn_linear_assignment(cost)
    ids=[obj_ids[i] for i in match_pairs[1]]
    return ids


def use_gt_mask(obj_masks):
    masks=np.zeros_like(obj_masks[0])
    ids=[]
    for i in range(len(obj_masks)):
        obj_mask=obj_masks[i]!=0
        masks[obj_mask]=(i+1)
        ids.append((i+1))
    return masks,ids


def seg_and_tracking(video_name,video_path, save_path,only_show_tracking_object=True):
    save_folder=save_path+video_name+'/'
    if not os.path.exists(save_folder):
        os.makedirs(save_folder)
    ### Set parameters for input and output
    io_args = {
        'video_base_path': video_path+f'{video_name}/',
        # 'video_base_path': f'/HDDs/hdd3/wff/documents/vot_challenge_test/sequences/{video_name}/',
        # 'video_base_path': f'/HDDs/hdd3/wff/documents/vots_test/sequences/{video_name}/',
        'output_mask_dir': save_folder+f'{video_name}_masks', # save pred masks
        'output_video': save_folder+f'{video_name}_seg.mp4', # mask+frame vizualization, mp4 or avi, else the same as input video
        'output_gif': save_folder+f'{video_name}_seg.gif', # mask visualization
        'output_txt':save_folder
    }
    io_args['input_video']=io_args['video_base_path']+'color/'

    ### Tuning SAM on the First Frame for Good Initialization

    # choose good parameters in sam_args based on the first frame segmentation result
    # other arguments can be modified in model_args.py
    # note the object number limit is 255 by default, which requires < 10GB GPU memory with amp
    sam_args['generator_args'] = {
        'points_per_side': 30,
        'pred_iou_thresh': 0.8,
        'stability_score_thresh': 0.9,
        'crop_n_layers': 1,
        'crop_n_points_downscale_factor': 2,
        'min_mask_region_area': 200,
    }

    # For every sam_gap frames, we use SAM to find new objects and add them for tracking
    # larger sam_gap is faster but may not spot new objects in time
    segtracker_args = {
        'sam_gap': 5,  # the interval to run sam to segment new objects
        'min_area': 200,  # minimal mask area to add a new mask as a new object
        'max_obj_num': 255,  # maximal object number to track in a video
        'min_new_obj_iou': 0.8,  # the area of a new object in the background should > 80%
    }

    # cap = cv2.VideoCapture(io_args['input_video'])

    image_list=sorted(os.listdir(io_args['input_video']))

    # 此代码只是用来测试第一帧分割结果，调参用
    frame_idx = 0
    segtracker = SegTracker(segtracker_args,sam_args,aot_args)
    segtracker.restart_tracker()
    with torch.cuda.amp.autocast():
        for img_name in image_list:
            frame=cv2.imread(io_args['input_video']+img_name)
            frame = cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
            width=frame.shape[1]
            height=frame.shape[0]
            pred_mask = segtracker.seg(frame)
            torch.cuda.empty_cache()
            obj_ids = np.unique(pred_mask)
            obj_ids = obj_ids[obj_ids!=0]
            print("Testing processed frame {}, obj_num {}".format(frame_idx,len(obj_ids)),end='\n')
            break

    # TODO 可视化
    # init_res = draw_mask(frame,pred_mask,id_countour=False)
    # plt.figure(figsize=(10,10))
    # plt.axis('off')
    # plt.imshow(init_res)
    # plt.show()
    # plt.figure(figsize=(10,10))
    # plt.axis('off')
    # plt.imshow(colorize_mask(pred_mask))
    # plt.show()

    del segtracker
    torch.cuda.empty_cache()
    gc.collect()
    ### Generate Results for the Whole Video

    # source video to segment
    # TODO 设置fps
    fps = 30
    # output masks

    pred_list = []
    masked_pred_list = []

    torch.cuda.empty_cache()
    gc.collect()
    sam_gap = segtracker_args['sam_gap']
    frame_idx = 0
    segtracker = SegTracker(segtracker_args, sam_args, aot_args)
    segtracker.restart_tracker()

    # TODO 新增读取初始帧
    dir_list=os.listdir(io_args['video_base_path'])
    first_frame_label=[i for i in dir_list if i.startswith('groundtruth')]
    first_frame_label=sorted(first_frame_label)
    obj_masks=[]
    for obj_label in first_frame_label:
        f=open(io_args['video_base_path']+obj_label,'r')
        line=f.readline()
        split_line=line.split(',')
        if split_line[1]!='0':
            print(video_name+' has wrong label type!')
            return
        mask=parse_region(line)
        obj_masks.append(mask.mask)
    obj_masks=np.array(obj_masks)
    # 得到的obj_masks即为第一帧要跟踪所有目标的mask


    with torch.cuda.amp.autocast():
        for img_name in image_list:
            # print('processing frame {}!'.format(img_name),end='\n')
            frame=cv2.imread(io_args['input_video']+img_name)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            if frame_idx == 0:
                pred_mask = segtracker.seg(frame)
                obj_ids=np.unique(pred_mask)
                obj_ids=obj_ids[obj_ids!=0]
                # ----
                # TODO 根据SAM预测分割结果作为第一帧mask
                # track_ids=find_tracking_ids(pred_mask,obj_ids,obj_masks)
                # TODO 根据gtmask作为第一帧mask
                pred_mask, track_ids=use_gt_mask(obj_masks)
                # ----
                torch.cuda.empty_cache()
                gc.collect()
                segtracker.add_reference(frame, pred_mask)
            elif (frame_idx % sam_gap) == 0:
                seg_mask = segtracker.seg(frame)
                torch.cuda.empty_cache()
                gc.collect()
                track_mask = segtracker.track(frame)
                # find new objects, and update tracker with new objects
                new_obj_mask = segtracker.find_new_objs(track_mask, seg_mask)
                # TODO 去除可视化
                # save_prediction(new_obj_mask, output_dir, str(frame_idx) + '_new.png')
                # ---------
                pred_mask = track_mask + new_obj_mask
                # segtracker.restart_tracker()
                segtracker.add_reference(frame, pred_mask)
            else:
                pred_mask = segtracker.track(frame, update_memory=True)
            torch.cuda.empty_cache()
            gc.collect()
            # TODO 去除可视化
            # save_prediction(pred_mask, output_dir, str(frame_idx) + '.png')
            # ---------
            # masked_frame = draw_mask(frame,pred_mask)
            # masked_pred_list.append(masked_frame)
            # plt.imshow(masked_frame)
            # plt.show()

            pred_list.append(pred_mask)

            print("processed frame {}, obj_num {}".format(frame_idx, segtracker.get_obj_num()))
            frame_idx += 1
        print('\nfinished')

    ### Save results for visualization

    # draw pred mask on frame and save as a video
    # cap = cv2.VideoCapture(io_args['input_video'])
    num_frames = len(image_list)


    fourcc =  cv2.VideoWriter_fourcc(*"mp4v")

    out = cv2.VideoWriter(io_args['output_video'], fourcc, fps, (width, height))

    frame_idx = 0
    for img_name in image_list:
        frame = cv2.imread(io_args['input_video'] + img_name)
        frame = cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
        pred_mask = pred_list[frame_idx]
        if only_show_tracking_object:
            # 只保留所需跟踪目标的mask
            frame_mask=np.zeros((height,width))
            for id in track_ids:
                frame_mask=np.logical_or(frame_mask,(pred_mask==id))
            my_mask=np.zeros_like(pred_mask)
            my_mask[frame_mask]=pred_mask[frame_mask]
            pred_list[frame_idx]=my_mask
            #------
            masked_frame = draw_mask(frame,my_mask)
        else:
            masked_frame = draw_mask(frame,pred_mask)
        masked_frame = cv2.cvtColor(masked_frame,cv2.COLOR_RGB2BGR)
        out.write(masked_frame)
        print('frame {} writed'.format(frame_idx))
        frame_idx += 1
    out.release()
    print("\n{} saved".format(io_args['output_video']))
    print('\nfinished')

    # save colorized masks as a gif
    # imageio.mimsave(io_args['output_gif'],pred_list,fps=fps)
    # imageio.mimsave(io_args['output_gif'],pred_list,duration=(1000/fps))
    # print("{} saved".format(io_args['output_gif']))
    # TODO 存储mask输出为txt
    for index,id in enumerate(track_ids):
        f=open(io_args['video_base_path']+first_frame_label[index],'r')
        line=f.readline().split(',')
        base_start=line[:4]
        result=[]
        for pred_mask in pred_list:
            res_line=map(str,base_start+mask_to_rle(pred_mask == id))
            result.append(','.join(res_line)+'\n')
        # 写入文件
        save_txt=io_args['output_txt']+'pred_obj'+str(index+1)+'.txt'
        with open(save_txt,'w') as f:
            for res in result:
                f.write(res)
    # ---------------
    # manually release memory (after cuda out of memory)
    del segtracker
    torch.cuda.empty_cache()
    gc.collect()


if __name__=='__main__':
    # 用来设置序列id
    seq_start_ind=107
    seq_end_ind=108
    seq_path='/HDDs/hdd3/wff/documents/vots_test/sequences'
    seq_list=os.listdir(seq_path)
    seq_list=[i for i in seq_list if i!='list.txt']
    seq_list=sorted(seq_list)
    for ind in range(seq_start_ind-1,seq_end_ind):
        print('Sequence '+seq_list[ind]+' testing!')
        seg_and_tracking(seq_list[ind],'/HDDs/hdd3/wff/documents/vots_test/sequences/', '/HDDs/hdd3/wff/documents/vots_test/results/')

    # TODO here
    # seg_and_tracking('giraffe-15','/HDDs/hdd3/wff/documents/vot_challenge_test/sequences/', '/HDDs/hdd3/wff/documents/vot_challenge_test/results/', only_show_tracking_object=True)