#!/usr/bin/python
import os
error_log = '/HDDs/hdd3/wff/documents/Segment-and-Track-Anything-main/error.log'
# try:
import sys
sys.path.append('/HDDs/hdd3/wff/documents/Segment-and-Track-Anything-main/')
import cv2
import traceback
# try:
from SegTracker import SegTracker
# except Exception as e:
#     error_line_info = traceback.format_exc()
#     with open(error_log, 'a') as f:
#         f.write(f'{e} start1 {error_line_info}\n')
from model_args import aot_args, sam_args, segtracker_args
# from PIL import Image
# from aot_tracker import _palette
import numpy as np
import torch
# import imageio
# import matplotlib.pyplot as plt
# from scipy.ndimage import binary_dilation
import gc
import my_vot

# import traceback

# with open(error_log, 'a') as f:
#     f.write(f'import finishing\n')




# 定义跟踪器
class SAM_Tracker(object):

    def __init__(self,image_path,masks):
        # choose good parameters in sam_args based on the first frame segmentation result
        # other arguments can be modified in model_args.py
        # note the object number limit is 255 by default, which requires < 10GB GPU memory with amp
        sam_args['generator_args'] = {
            'points_per_side': 30,
            'pred_iou_thresh': 0.8,
            'stability_score_thresh': 0.9,
            'crop_n_layers': 1,
            'crop_n_points_downscale_factor': 2,
            'min_mask_region_area': 200,
        }

        # For every sam_gap frames, we use SAM to find new objects and add them for tracking
        # larger sam_gap is faster but may not spot new objects in time
        segtracker_args = {
            # sam_gap默认5
            'sam_gap': 20,  # the interval to run sam to segment new objects
            'min_area': 200,  # minimal mask area to add a new mask as a new object
            'max_obj_num': 2*len(masks),  # maximal object number to track in a video
            'min_new_obj_iou': 0.8,  # the area of a new object in the background should > 80%
        }
        self.frame_idx=0
        self.segtracker =SegTracker(segtracker_args, sam_args, aot_args)
        self.segtracker.restart_tracker()
        frame = cv2.imread(image_path)
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        self.width=frame.shape[1]
        self.height=frame.shape[0]
        self.sam_gap=segtracker_args['sam_gap']
        self.obj_masks=masks
        with torch.cuda.amp.autocast():
            pred_mask, self.track_ids = self.use_gt_mask(self.obj_masks)
            self.segtracker.add_reference(frame, pred_mask)
            torch.cuda.empty_cache()
            gc.collect()
        self.frame_idx+=1


    def track(self,image_file):
        with torch.cuda.amp.autocast():
            frame = cv2.imread(image_file)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            if (self.frame_idx % self.sam_gap) == 0:
                seg_mask = self.segtracker.seg(frame)
                torch.cuda.empty_cache()
                gc.collect()
                track_mask = self.segtracker.track(frame)
                # find new objects, and update tracker with new objects
                new_obj_mask = self.segtracker.find_new_objs(track_mask, seg_mask)
                pred_mask = track_mask + new_obj_mask
                self.segtracker.add_reference(frame, pred_mask)
            else:
                pred_mask = self.segtracker.track(frame, update_memory=True)
            torch.cuda.empty_cache()
            gc.collect()
            result=[]
            for id in self.track_ids:
                one_mask=np.zeros_like(pred_mask,dtype=np.uint8)
                mask=pred_mask==id
                one_mask[mask]=1
                result.append(one_mask)
            self.frame_idx+=1
            return result

    def delete_tracker(self):
        del self.segtracker
        torch.cuda.empty_cache()
        gc.collect()

    def use_gt_mask(self,obj_masks):
        masks = np.zeros_like(obj_masks[0])
        ids = []
        for i in range(len(obj_masks)):
            obj_mask = obj_masks[i] != 0
            masks[obj_mask] = (i + 1)
            ids.append((i + 1))
        return masks, ids


# with open(error_log, 'a') as f:
#     f.write(f'sam tracker finishing\n')

handle = my_vot.VOT("mask", multiobject=True)
objects = handle.objects()
imagefile = handle.frame()
tracker = SAM_Tracker(imagefile,objects)
while True:
    imagefile = handle.frame()
    if not imagefile:
        tracker.delete_tracker()
        break
    handle.report(tracker.track(imagefile))
# except Exception as e:
#     error_line_info = traceback.format_exc()
#     with open(error_log, 'a') as f:
#         f.write(f'{e} - {error_line_info}\n')